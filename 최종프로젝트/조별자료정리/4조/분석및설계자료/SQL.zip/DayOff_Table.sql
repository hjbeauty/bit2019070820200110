CREATE TABLE `deliver` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `name` VARCHAR(50) NULL,
 `location` VARCHAR(100) NOT NULL,
 `postalCode` VARCHAR(10) NULL,
 `phone` VARCHAR(20) NULL,
 `userId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `orderGroup` (
 `tid` VARCHAR(50) NOT NULL PRIMARY KEY,
 `userId` INT NOT NULL,
 `totalPay` INT NULL,
 `orderDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `gradeDiscount` INT NULL,
 `pointUse` INT NULL,
 `deliverId` INT NULL,
 `storesId` INT NULL,
 `invoice` VARCHAR(100) NULL,
 `aid` VARCHAR(50) NULL,
 `cid` VARCHAR(50) NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `users` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `socialId` VARCHAR(200) NOT NULL,
 `name`	VARCHAR(20) NULL,
 `birth` DATE NULL,
 `sex` VARCHAR(5) NULL,
 `height` VARCHAR(5) NULL,
 `weight` VARCHAR(5) NULL,
 `phone` VARCHAR(20) NULL,
 `accrue` INT NULL DEFAULT 0,
 `level` VARCHAR(20) NULL DEFAULT '브론즈',
 `role`	VARCHAR(10) NULL DEFAULT 'user',
 `signUpDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `accessToken` VARCHAR(200) NULL,
 `refreshToken` VARCHAR(200) NULL,
 `totalEmoney` INT NULL DEFAULT 1000
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `review` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `title` VARCHAR(200) NOT NULL,
 `content` VARCHAR(1000) NULL,
 `reviewDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `rating` INT NOT NULL,
 `userId` INT NOT NULL,
 `productId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


CREATE TABLE `stores` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `name` VARCHAR(20) NULL,
 `location` VARCHAR(100) NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `grade` (
 `level` VARCHAR(20) NOT NULL PRIMARY KEY,
 `rate`	INT NULL,
 `required` INT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `refunds` (
 `orderId` INT NOT NULL PRIMARY KEY,
 `code` VARCHAR(4) NULL,
 `requestDate` DATETIME	NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `refundDate` DATETIME NULL,
 `refundAmount` INT
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `cart` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `productId` INT NOT NULL,
 `color` VARCHAR(20) NULL,
 `size`	VARCHAR(20) NULL,
 `quantity` INT NULL,
 `cartDate` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
 `price` INT NULL,
 `userId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `product` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `name` VARCHAR(100) NULL,
 `price` INT NULL,
 `detailImage` VARCHAR(100) NULL,
 `registerDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `categoryId` INT NULL,
 `isAvailable` TINYINT NULL DEFAULT 1
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `category` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `name`	VARCHAR(100) NULL,
 `subName` VARCHAR(100)	NULL,
 `engName` VARCHAR(100) NULL 
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `color` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `color` VARCHAR(20) NOT NULL,
 `image` VARCHAR(100) NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `productColor` (
 `productId` INT NOT NULL,
 `colorId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `productSize` (
 `productId` INT NOT NULL,
 `size` VARCHAR(20) NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `productImage` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `name` VARCHAR(200) NULL,
 `originalName`	VARCHAR(100) NOT NULL,
 `productId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `orders` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `groupId` VARCHAR(50) NOT NULL,
 `productId` INT NULL,
 `color` VARCHAR(20) NULL,
 `size`	VARCHAR(20) NULL,
 `quantity` INT NULL,
 `price` INT NULL,
 `code` VARCHAR(4) NULL,
 `deliverDate` DATE NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `loginHistory` (
 `id` INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
 `loginDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 `userId` INT NOT NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `code` (
 `code` VARCHAR(4) NOT NULL PRIMARY KEY,
 `content` VARCHAR(200)	NULL
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `withdrawHistory` (
 `userId` INT NOT NULL PRIMARY KEY,
 `code`	VARCHAR(4) NULL,
 `withdrawDate` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


ALTER TABLE `productColor` ADD CONSTRAINT `PK_PRODUCTCOLOR` PRIMARY KEY (
 `productId`,
 `colorId`
);

ALTER TABLE `productSize` ADD CONSTRAINT `PK_PRODUCTSIZE` PRIMARY KEY (
 `size`,
 `productId`
);

ALTER TABLE `deliver` ADD CONSTRAINT `FK_users_TO_deliver_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `orderGroup` ADD CONSTRAINT `FK_users_TO_orderGroup_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `orderGroup` ADD CONSTRAINT `FK_deliver_TO_orderGroup_1` FOREIGN KEY (
 `deliverId`
)
REFERENCES `deliver` (
 `id`
);

ALTER TABLE `orderGroup` ADD CONSTRAINT `FK_stores_TO_orderGroup_1` FOREIGN KEY (
 `storesId`
)
REFERENCES `stores` (
 `id`
);

ALTER TABLE `users` ADD CONSTRAINT `FK_grade_TO_users_1` FOREIGN KEY (
 `level`
)
REFERENCES `grade` (
 `level`
) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `review` ADD CONSTRAINT `FK_users_TO_review_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `review` ADD CONSTRAINT `FK_product_TO_review_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE CASCADE;


ALTER TABLE `refunds` ADD CONSTRAINT `FK_orders_TO_refunds_1` FOREIGN KEY (
 `orderId`
)
REFERENCES `orders` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `refunds` ADD CONSTRAINT `FK_code_TO_refunds_1` FOREIGN KEY (
 `code`
)
REFERENCES `code` (
 `code`
) ON DELETE SET NULL ON UPDATE CASCADE;


ALTER TABLE `cart` ADD CONSTRAINT `FK_product_TO_cart_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `cart` ADD CONSTRAINT `FK_users_TO_cart_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `product` ADD CONSTRAINT `FK_category_TO_product_1` FOREIGN KEY (
 `categoryId`
)
REFERENCES `category` (
 `id`
) ON DELETE SET NULL;

ALTER TABLE `productColor` ADD CONSTRAINT `FK_product_TO_productColor_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `productColor` ADD CONSTRAINT `FK_color_TO_productColor_1` FOREIGN KEY (
 `colorId`
)
REFERENCES `color` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `productSize` ADD CONSTRAINT `FK_product_TO_productSize_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `productImage` ADD CONSTRAINT `FK_product_TO_productImage_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE CASCADE;

ALTER TABLE `orders` ADD CONSTRAINT `FK_orderGroup_TO_orders_1` FOREIGN KEY (
 `groupId`
)
REFERENCES `orderGroup` (
 `tid`
) ON DELETE CASCADE;

ALTER TABLE `orders` ADD CONSTRAINT `FK_product_TO_orders_1` FOREIGN KEY (
 `productId`
)
REFERENCES `product` (
 `id`
) ON DELETE SET NULL;

ALTER TABLE `loginHistory` ADD CONSTRAINT `FK_users_TO_loginHistory_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `withdrawHistory` ADD CONSTRAINT `FK_users_TO_withdrawHistory_1` FOREIGN KEY (
 `userId`
)
REFERENCES `users` (
 `id`
);

ALTER TABLE `withdrawHistory` ADD CONSTRAINT `FK_code_TO_withdrawHistory_1` FOREIGN KEY (
 `code`
)
REFERENCES `code` (
 `code`
) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `orders` ADD CONSTRAINT `FK_code_TO_orders_1` FOREIGN KEY (
 `code`
)
REFERENCES `code` (
 `code`
) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE orders drop foreign key FK_orderGroup_TO_orders_1;
alter table orderGroup modify tid varchar(40);
alter table orders modify groupId varchar(40);
ALTER TABLE `orders` ADD CONSTRAINT `FK_orderGroup_TO_orders_1` FOREIGN KEY (
 `groupId`
)
REFERENCES `orderGroup` (
 `tid`
) ON DELETE CASCADE;

