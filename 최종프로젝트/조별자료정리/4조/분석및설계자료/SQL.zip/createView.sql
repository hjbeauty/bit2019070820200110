drop view productView;
drop view orderDetailView;
drop view orderView;
drop view cartView;
drop view recommendByCategory;

create view recommendByCategory as select p.name productName, c.engName categoryName, c.subName categorysubName, p.id productId, pic.name productThumbnailName, p.price from 
 product p join (select pib.* from (select pi.productId,MIN(pi.name) name from 
productImage pi join product p2 on pi.productId = p2.id group by p2.id) pib join product p3 on pib.productId = p3.id) pic 
on pic.productId = p.id  join category c on c.id = p.categoryId where p.isAvailable = 1 order by p.registerDate desc;


CREATE VIEW `productView` AS SELECT p.id, p.name, p.price, p.registerDate, p.categoryId, c.name categoryName, c.subName categorySubName, p.isAvailable, pic.name productThumbnailName, orderCount FROM product p INNER JOIN category c ON p.categoryId=c.id INNER JOIN (SELECT pib.* FROM (SELECT productId, MIN(id) id FROM productImage GROUP BY productId) pia INNER JOIN productImage pib ON pia.id=pib.id) pic ON p.id=pic.productId LEFT JOIN (SELECT productId, COUNT(*) orderCount FROM orders GROUP BY productId) o ON o.productId=p.id;


CREATE VIEW `orderDetailView` AS SELECT o.id orderId, p.id productId, pi.name productThumbnailName, p.name productName, p.price productPrice, p.isAvailable productIsAvailable, o.color orderColor, o.size orderSize, o.quantity orderQuantity, o.price orderPrice, c.code code, c.content codeContent, og.tid groupId, u.id userId, u.name userName, og.totalPay, og.orderDate, og.gradeDiscount, og.pointUse, og.invoice, r.requestDate refundRequestDate, r.refundDate, r.refundAmount, og.storesId, s.name storesName, s.location storesLocation, og.deliverId, d.name deliverName, d.location deliverLocation, d.postalCode deliverPostalCode, d.phone deliverPhone FROM orderGroup og inner join orders o on o.groupId=og.tid inner join product p on o.productId=p.id left join code c on c.code=o.code left join deliver d on d.id=og.deliverId left join stores s on s.id=og.storesId inner join (select pib.* from (select productId, MIN(id) id from productImage group by productId) pia inner join productImage pib on pia.id=pib.id) pi on p.id=pi.productId left join refunds r on r.orderId=o.id left join users u on u.id=og.userId;


create view orderView as 
select  u.id userId, o.deliverDate, u.name userName, og.tid groupId, o.id orderId, o.color orderColor,o.size orderSize, o.quantity orderQuantity, p.id productId, p.name productName, p.isAvailable productIsAvailable, pi.name productThumbnailName, og.orderDate, og.gradeDiscount, og.pointUse, og.totalPay totalPay, o.price orderPrice, og.invoice, c.code code, c.content codeContent
from users u join orderGroup og on u.id = og.userId join orders o on og.tid = o.groupId join product p on p.id = o.productId 
join (select pib.* from (select productId, MIN(id) id from productImage group by productId) 
pia inner join productImage pib on pia.id=pib.id) pi on pi.productId = p.id left join code c on c.code=o.code order by og.orderDate desc;


CREATE VIEW `cartView` AS
select c.id,c.color,c.size,c.quantity,c.price totalPrice,c.userId,p.id productId,p.name,p.price,pic.name productThumbnailName from cart c inner join product p on c.productId=p.id inner join   (SELECT pib.* FROM (SELECT productId, MIN(id) id FROM productImage GROUP BY productId) pia INNER JOIN productImage pib ON pia.id=pib.id) pic ON p.id=pic.productId;
