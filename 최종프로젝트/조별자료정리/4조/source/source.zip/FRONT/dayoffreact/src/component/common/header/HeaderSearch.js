import React, { Component } from 'react'
import './header.css';
import Contact from './Contact';

export default class HeaderSearch extends Component {

  render() {
    return (
      <div className='HeaderSearch'>
        <Contact />
        </div>
    )}
}
