import React, { Component } from 'react';

export default class deny extends Component {
  render() {
    return (
      <div> <h1> 접근 권한이 없습니다.</h1> </div>
    );
  }
}
