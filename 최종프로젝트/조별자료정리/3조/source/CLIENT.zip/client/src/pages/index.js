export { default as Home } from './Home';
export { default as Login } from './Login';
export { default as Register } from './Register';

export { default as MyShow} from './MyShow';
export { default as QNA} from './QNA';
export { default as ClientInformation} from './ClientInformation';
export { default as ClientInformation2} from './ClientInformation2';
export { default as QNAInsert} from './QNAInsert';
export { default as QNAUpdate} from './QNAUpdate';
export { default as Schedule} from './Schedule';
