import React, { Component } from 'react';

export default class ServiceStats extends Component {
  render() {
    return (
      <div class="card col-4">
        <div class="card-header d-flex justify-content-between">
          <h5 class="card-title m-0">
            서비스 이용 통계
          </h5>
          <a href="#" class="text-light">
            <i class="fas fa-ellipsis-v"></i>
          </a>
        </div>

        <div class="card-body">
        


        </div>
      </div>
    );
  }
}