package org.salem.domain.vo;

import lombok.Data;

@Data
public class BreedVO {
	
	private int breedNo;            //견종번호  
	private String dogBreed;       //견종 
	private String size;           // 견종 사이즈 
	private int dayPrice;
	private int homePrice;

	
	
	

}
