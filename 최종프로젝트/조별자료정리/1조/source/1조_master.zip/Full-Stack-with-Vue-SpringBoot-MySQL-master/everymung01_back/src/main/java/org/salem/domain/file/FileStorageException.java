package org.salem.domain.file;

public class FileStorageException  extends RuntimeException {         // 일반유저가 펫 이미지 추가및 자기 집 이미지 추가 관련클래스
	
	public FileStorageException(String message) {
		super(message);
	}
	
	public FileStorageException(String message, Throwable cause) {
		super(message, cause);
	}
	
	
	
	
	
	
	
	
	

}
