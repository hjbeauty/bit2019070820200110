package org.salem.domain.vo;

import lombok.Data;

@Data
public class PetInfoVO {
	
	protected int petNo;
	protected String size;
	protected String petName;
	
}
