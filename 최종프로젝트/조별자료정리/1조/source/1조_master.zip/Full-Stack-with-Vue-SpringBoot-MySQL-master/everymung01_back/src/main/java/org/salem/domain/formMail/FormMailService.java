package org.salem.domain.formMail;

public interface FormMailService {
	
	void sendEmail(String email) throws Exception;

}
