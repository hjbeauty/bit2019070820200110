
package org.salem.domain;

import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;

//@RunWith(SpringRunner.class)
@SpringBootTest
class MariaJpaApplicationTests {

	
	@Test
	void contextLoads() {
//	File lsm = new File("C:/git/Full-Stack-with-Vue-SpringBoot-MySQL/everymung01_back/uploads/permit.PNG");
//	System.out.println(lsm.exists());
//	System.out.println(lsm.getPath());
//	System.out.println(lsm.delete());
//	System.out.println(lsm.exists());
	}
}

//
//package org.salem.domain;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//class MariaJpaApplicationTests {
//
//	@Autowired
//	UsersRepository rep;
//	
//	@Autowired
//	LsmMapper mapper;
//	@Test
//	void contextLoads() {
//		Users lsm = new Users();
//		lsm.setAddress("서울시");
//		lsm.setEmail("lsm@nav.com");
//		lsm.setName("lsm");
//		lsm.setPw("qwe");
//		lsm.setId("1");
//		
//		System.out.println(rep.save(lsm));
//	}
//}
