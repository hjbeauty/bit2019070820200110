package org.salem.domain.vo;

import lombok.Data;

@Data
public class PriceVO {
	
	private String size;
	private int homePrice;
	private int dayPrice;
}
