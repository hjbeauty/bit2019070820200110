<template>
<v-container>
    <h1>에브리댕에 지원해 주셔서 감사합니다!</h1>
    <p>지원 결과는 추후 이메일로 통지될 예정입니다</p>
<br><br><br>
<v-btn  @click="$router.push({name : 'home'})" depressed>메인으로</v-btn>
</v-container>
</template>
<script>
export default {
    
}
</script>