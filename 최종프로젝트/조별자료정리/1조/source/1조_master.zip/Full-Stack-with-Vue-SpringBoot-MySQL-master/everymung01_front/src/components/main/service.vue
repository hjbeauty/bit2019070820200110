<template>
    <div>
        <v-row justify="center" class="mt-9">
      <h1>에브리멍의 펫 서비스</h1>
    </v-row>
    <v-row justify="center">
      <v-col cols="4">
        <v-card
          class="mx-auto my-12"
          max-width="374"
        >
          <v-img
            height="250"
            src="https://images.unsplash.com/photo-1520891309540-863309442d8a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1041&q=80"
          ></v-img>

          <v-card-title class="justify-center">하루 시터</v-card-title>

          <v-card-text class="text-center">
            <div>내가 나가있는 동안, 우리 강아지는 어떡하지?</div>
            <div>이제는 집으로 찾아오는 에브리멍에게 맡기세요!</div>
          </v-card-text>

          <v-divider class="mx-4"></v-divider>

          <v-card-actions class="justify-center">
            <v-btn
              color="deep-purple accent-4"
              text
            >
              예약하기
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
      <v-col cols="4">
        <v-card
          class="mx-auto my-12"
          max-width="374"
        >
          <v-img
            height="250"
            src="https://images.unsplash.com/photo-1510563800743-aed236490d08?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80"
          ></v-img>

          <v-card-title class="justify-center">위탁 시터</v-card-title>

          <v-card-text class="text-center">
            <div>여행 가고 싶은데, 혼자 남겨진 반려동물은 어떡하지?</div>
            <div>답답한 애견호텔보다 펫시터에게 직접 맡기세요!</div>
          </v-card-text>

          <v-divider class="mx-4"></v-divider>

          <v-card-actions class="justify-center">
            <v-btn
              color="deep-purple accent-4"
              text
            >
              예약하기
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
      <v-col cols="4">
        <v-card
          class="mx-auto my-12"
          max-width="374"
        >
          <v-img
            height="250"
            src="https://images.unsplash.com/photo-1478558393578-343e5e0128e9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=634&q=80"
          ></v-img>

          <v-card-title class="justify-center">펫시터 지원</v-card-title>

          <v-card-text class="text-center">
            <div>편안한 우리집에서 원하는 날만 자유롭게 반려동물 돌보며 부수입을 벌어보세요!</div>
          </v-card-text>

          <v-divider class="mx-4"></v-divider>

          <v-card-actions class="justify-center">
            <v-btn
              color="deep-purple accent-4"
              text
            >
              지원하기
            </v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
    </div>
</template>