create sequence free_seq start with 1 increment by 1; 

create table free( 
  code number(10) CONSTRAINT free_PK PRIMARY KEY,
  title VARCHAR2(250),
  content VARCHAR2(1000),
  writer VARCHAR2(50),
  reg_datetime date default sysdate
);