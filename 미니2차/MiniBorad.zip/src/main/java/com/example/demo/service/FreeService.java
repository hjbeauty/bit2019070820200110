package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Free;
import com.example.demo.mapper.FreeMapper;

@Service
public class FreeService {
	@Autowired
	FreeMapper freeMapper;
	
	public List<Free> getFree(){
		return freeMapper.selectFree();
	}
	
	public void addFree(Free free) {
		freeMapper.insertFree(free);
	}
	
	public Free oneFree(int code) {
		return freeMapper.detailFree(code);
	}
	public void changeFree(Free free) {
		freeMapper.updateFree(free);
	}
	
	public void removeFree(int code) {
		freeMapper.deleteFree(code);
	}

}
