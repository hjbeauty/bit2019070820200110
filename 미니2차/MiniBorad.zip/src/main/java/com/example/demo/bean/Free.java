package com.example.demo.bean;

import org.apache.ibatis.type.Alias;

@Alias("Free")
public class Free {
	private int code;
	private String title;
	private String content;
	private String writer;
	private String reg_datetime;
	
	
	public Free() {
		// TODO Auto-generated constructor stub
	}


	public Free(int code, String title, String content, String writer, String reg_datetime) {
		super();
		this.code = code;
		this.title = title;
		this.content = content;
		this.writer = writer;
		this.reg_datetime = reg_datetime;
	}


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}


	public String getWriter() {
		return writer;
	}


	public void setWriter(String writer) {
		this.writer = writer;
	}


	public String getReg_datetime() {
		return reg_datetime;
	}


	public void setReg_datetime(String reg_datetime) {
		this.reg_datetime = reg_datetime;
	}


	@Override
	public String toString() {
		return "Free [code=" + code + ", title=" + title + ", content=" + content + ", writer=" + writer
				+ ", reg_datetime=" + reg_datetime + "]";
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((content == null) ? 0 : content.hashCode());
		result = prime * result + ((reg_datetime == null) ? 0 : reg_datetime.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((writer == null) ? 0 : writer.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Free other = (Free) obj;
		if (code != other.code)
			return false;
		if (content == null) {
			if (other.content != null)
				return false;
		} else if (!content.equals(other.content))
			return false;
		if (reg_datetime == null) {
			if (other.reg_datetime != null)
				return false;
		} else if (!reg_datetime.equals(other.reg_datetime))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (writer == null) {
			if (other.writer != null)
				return false;
		} else if (!writer.equals(other.writer))
			return false;
		return true;
	}
	
	

}
