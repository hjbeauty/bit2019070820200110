package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.bean.Free;
import com.example.demo.service.FreeService;

@Controller
public class FreeController {
	@Autowired
	FreeService freeService;
	@RequestMapping("/")
	public String main(Model model) {
		model.addAttribute("list", freeService.getFree());
		return "list";
	}
	
	@RequestMapping("/list")
	public void freeList(Model model, Free free) {
		freeService.addFree(free);
		model.addAttribute("list",freeService.getFree());
	}
	
	@RequestMapping("/index")
	public void freeInsert(@ModelAttribute Free free) {
		
	}
	
	@RequestMapping("/one")
	public void freeOne(Model model, @RequestParam("code") int code) {
		Free free = freeService.oneFree(code);
		model.addAttribute("free", free);
	}
	
	@RequestMapping("/update/{code}")
	public String freeUpdate(Model model, @PathVariable("code") int code) {
		model.addAttribute("free", freeService.oneFree(code));
		return "/update";
	}
	
	@RequestMapping("/update2")
	public String freeUpdate(Model model, @ModelAttribute Free free) {
		freeService.changeFree(free);
		model.addAttribute("list", freeService.getFree());
		return "/update2";
	}
	
	@RequestMapping("/remove")
	public void freeRemove(Model model, @RequestParam("code") int code) {
		freeService.removeFree(code);
		model.addAttribute("list", freeService.getFree());
	}
}
