package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo.bean.Free;

@Mapper
public interface FreeMapper {
	
	@Select("select * from free order by code desc")
	public List<Free> selectFree();
	
	@Insert("insert into free(code, title, content, writer, reg_datetime)"
			+ "values(free_seq.nextval, #{title}, #{content}, #{writer}, default)")
	public void insertFree(Free free);
	
	@Select("select * from free where code= #{code}")
	public Free detailFree(int code);
	
	@Update("update free set title = #{title}, content = #{content}, writer = #{writer} where code = #{code}")
	public void updateFree(Free free);
	
	@Delete("delete from free where code = #{code}")
	public void deleteFree(int code);


}
