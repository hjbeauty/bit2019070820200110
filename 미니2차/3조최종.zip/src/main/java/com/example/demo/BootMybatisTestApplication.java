package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMybatisTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootMybatisTestApplication.class, args);
	}

}
