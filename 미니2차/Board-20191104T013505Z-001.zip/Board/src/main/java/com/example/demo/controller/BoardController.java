package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.bean.Board;
import com.example.demo.bean.Reply;
import com.example.demo.service.BoardService;
import com.example.demo.service.ReplyService;

@Controller
public class BoardController {
	@Autowired
	BoardService boardService;
	@Autowired
	ReplyService replyService;

	@RequestMapping("/alist")
	public void boardList(Model model, Board board) {
		boardService.addBoard(board);
		System.out.println(boardService.getList());
		model.addAttribute("list", boardService.getList());
	}

	@RequestMapping("/Boardmain")
	public void boardcreate(@ModelAttribute Board board) {

	}

	@RequestMapping("/content")
	public void boardmenu(Model model, @RequestParam("bno") int bno, @ModelAttribute Reply reply) {
		Board board = boardService.getDetail(bno);
		model.addAttribute("board", board);
		model.addAttribute("reply_",replyService.selList(bno));


	}

	@RequestMapping("/delete")
	public void delete(Model model, @RequestParam("bno") int bno) {
		boardService.deletedata(bno);
		replyService.deletedata(bno);
		model.addAttribute("list", boardService.getList());

	}

	@RequestMapping("/aupdate")
	public void update(Model model, @RequestParam("bno") int bno) {
		Board board = boardService.getDetail(bno);
		model.addAttribute("boardup", board);

	}

	@RequestMapping("/updatecontent")
	public void updatecontents(Model model, @RequestParam("bno") int bno, @RequestParam("contents") String contents) {
		boardService.updatedata(bno, contents);
		model.addAttribute("list", boardService.getList());

	}

	@RequestMapping("/main")
	public void firstmain(Model model) {
		model.addAttribute("list", boardService.getList());
	}

	@RequestMapping("/reply")
	public void replycreate(@ModelAttribute Reply reply, Model model, @RequestParam("bno") int bno) {
		model.addAttribute("bno", bno);
	}

	@RequestMapping("/replylist")
	public void replyadd(Model model, @RequestParam("bno") int bno, @ModelAttribute Reply reply) {
		replyService.addReply(reply);
		Board board = boardService.getDetail(bno);
		model.addAttribute("board", board);
		model.addAttribute("reply_",replyService.selList(bno));
	}

}
