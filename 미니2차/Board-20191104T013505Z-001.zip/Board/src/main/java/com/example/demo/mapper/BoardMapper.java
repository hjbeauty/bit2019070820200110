package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo.bean.Board;

@Mapper
public interface BoardMapper {
	@Insert("Insert into board(bno,title,username,contents,regdate) values(seq_.nextval,#{title},#{username},#{contents},default)")
	public void insert(Board board);

	@Select("select * from board order by bno")
	public List<Board> showList();
	@Select("select * from board where bno=#{bno}")
	public Board detail(int bno);
	@Delete("delete from board where bno=#{bno}")
	public void delete(int bno);
	@Update("update board set contents=#{contents}, regdate=sysdate where bno=#{bno}")
	public void update(int bno,String contents);
	
	
	}
