package com.example.demo.bean;

import java.sql.Timestamp;

public class Reply {
int rno;
String username;
String contents;
int bno;
String regdate;

public int getBno() {
	return bno;
}
public void setBno(int bno) {
	this.bno = bno;
}
public int getRno() {
	return rno;
}
public void setRno(int rno) {
	this.rno = rno;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}

public String getContents() {
	return contents;
}
public void setContents(String contents) {
	this.contents = contents;
}
public String getRegdate() {
	return regdate;
}
public void setRegdate(String regdate) {
	this.regdate = regdate;
}
@Override
public String toString() {
	return "Reply [rno=" + rno + ", username=" + username + ", contents=" + contents + ", bno=" + bno + ", regdate="
			+ regdate + "]";
}



}
