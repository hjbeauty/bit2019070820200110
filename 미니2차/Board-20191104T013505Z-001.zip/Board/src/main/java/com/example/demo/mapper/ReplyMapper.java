package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.example.demo.bean.Board;
import com.example.demo.bean.Reply;

@Mapper
public interface ReplyMapper {
	@Insert("Insert into reply(rno,username,contents,bno,regdate) values(reseq_.nextval,#{username},#{contents},#{bno},default)")
	public void insert(Reply reply);
	@Select("select * from reply order by rno")
	public List<Reply> showList();
	@Select("select * from reply where bno=#{bno}")
	public List<Reply> selectList(int bno);
	@Delete("delete from reply where bno=#{bno}")
	public void delete(int bno);
	
	}
