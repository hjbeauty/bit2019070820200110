package com.example.demo.bean;

import java.sql.Timestamp;

public class Board {
int bno;
String username;
String title;
String contents;
String regdate;


public String getRegdate() {
	return regdate;
}
public void setRegdate(String regdate) {
	this.regdate = regdate;
}
public int getBno() {
	return bno;
}
public void setBno(int bno) {
	this.bno = bno;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getContents() {
	return contents;
}
public void setContents(String contents) {
	this.contents = contents;
}
@Override
public String toString() {
	return "Board [bno=" + bno + ", username=" + username + ", title=" + title + ", contents=" + contents + ", regdate="
			+ regdate + "]";
}


}
