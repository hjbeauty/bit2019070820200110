package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Board;
import com.example.demo.mapper.BoardMapper;

@Service
public class BoardService {
	@Autowired
	BoardMapper boardMapper;

	public void addBoard(Board board) {
		boardMapper.insert(board);
	}

	public List<Board> getList() {
		return boardMapper.showList();
	}

	public Board getDetail(int bno) {
		return boardMapper.detail(bno);
	}

	public void deletedata(int bno) {
		boardMapper.delete(bno);

	}
	public void updatedata(int bno,String contents) {
		boardMapper.update(bno,contents);

	}

}
