package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Board;
import com.example.demo.bean.Reply;
import com.example.demo.mapper.ReplyMapper;

@Service
public class ReplyService {
	@Autowired
	ReplyMapper replyMapper; 

	public void addReply(Reply reply) {
		replyMapper.insert(reply);
	}

	public List<Reply> getList() {
		return replyMapper.showList();
	}
	public List<Reply> selList(int bno) {
		return replyMapper.selectList(bno);
	}
	public void deletedata(int rno) {
		replyMapper.delete(rno);

	}

}
