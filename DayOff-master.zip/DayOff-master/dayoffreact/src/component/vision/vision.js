import React, { Component } from 'react';
import VisionMain from "./visionCrop"

class vision extends Component {
    render() {
        return (
            <div>
                <VisionMain></VisionMain>
            </div>
        );
    }
}

export default vision;