import React from 'react';
import GoogleMapsContainer from './GoogleMapsContainer';
import './googleMapMap.css';

function MapPage() {
  return (
      <div className ='MapCss'>
          <GoogleMapsContainer />
          </div>
  );
}

export default MapPage;
