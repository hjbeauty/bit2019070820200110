import React from 'react';
import logo from './logo.svg';
import './App.css';
import TestComponent from './component/TestComponent';

function App() {
  return (
    <div className="App">
      <TestComponent></TestComponent>
    </div>
  );
}

export default App;
