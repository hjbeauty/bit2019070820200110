--schema.sql

--일반형 리스트
CREATE TABLE List_Board( 
	idx NUMBER NOT NULL,
	title VARCHAR2(20) NOT NULL,
	writer VARCHAR2(20) NOT NULL,
	content VARCHAR2(5000) NOT NULL,
	reg_date  DATE DEFAULT SYSDATE,
	view_cnt NUMBER DEFAULT 0,
	PRIMARY KEY(idx)
);

--계단형리스트
CREATE TABLE stair_shaped_board(
	no NUMBER(4) PRIMARY KEY,
	grpno NUMBER(4) NOT NULL,
	prntno NUMBER(4) REFERENCES stair_shaped_board(no) ON DELETE CASCADE,
	title VARCHAR2(100),
	writer VARCHAR2(50),
	content VARCHAR2(4000),
	regdate DATE DEFAULT SYSDATE,
	hits NUMBER(4) DEFAULT 0
);

--갤러리형 리스트
CREATE TABLE Gallery_Board(
    no NUMBER(4) PRIMARY KEY,
	title VARCHAR2(20),
 	writer VARCHAR2(10),
	content VARCHAR2(500),
	regdate DATE DEFAULT SYSDATE,
	image VARCHAR2(50),
	count NUMBER(10) DEFAULT 0
);
create table gallery_files(
	fno number(4) PRIMARY KEY,
	no number(4) REFERENCES Gallery_Board(no) ON DELETE CASCADE,
	filename varchar2(200),
	fileOriName varchar2(300),
	fileurl varchar2(500) 
);

--파일 업로드 리스트
CREATE TABLE file_board(
	b_no NUMBER(5) PRIMARY KEY,
	title VARCHAR2(100) NOT NULL,
  	content VARCHAR2(1000),
  	writer VARCHAR2(30),
  	reg_date DATE DEFAULT SYSDATE
);
CREATE TABLE files(
  	f_no NUMBER(5) PRIMARY KEY,
  	b_no NUMBER(5) NOT NULL,
  	file_name VARCHAR2(200) NOT NULL,
  	file_name_origin VARCHAR2(300) NOT NULL,
 	file_url VARCHAR2(500) NOT NULL
);
