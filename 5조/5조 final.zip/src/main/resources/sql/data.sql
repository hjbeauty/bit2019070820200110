--리스트형 게시판
create sequence List_Board_seq start with 1 increment by 1 nomaxvalue nocache;  
INSERT INTO
		List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
		(List_Board_seq.nextval,'ah','ahh','ahhhhh',default,default);

-- 계단형
CREATE SEQUENCE stair_shaped_board_seq;

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '안녕하세요', '상희', '즐거운 금요일'
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, 'RE:안녕하세요', '상희', '불타는 금요일'
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 2, 'RE:RE:안녕하세요', '상희', '불불불'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, 'RE:안녕하세요22', '상희', '불타는 금요일22'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '5시에요', '상희', '이제드디어'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 3, 'RE:RE:RE:안녕안녕', '상희', '금욜'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 5, 5, 'RE:5시시에요', '상희', '금욜'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 5, 5, 'RE:5시에요2', '상희', '금욜'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '헷갈려', '상희', '으오'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 9, 9, 'RE:헷갈려', '상희', '으오'
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content) VALUES(
stair_shaped_board_seq.NEXTVAL, 5, 7, 'RE:RE:5시시시ㅣ', '상희', 'ㅇㅇㅇ'
);


-- 갤러리형
-- gallery_board sequence 생성 및 삭제
CREATE SEQUENCE  BoardId_seq;
DROP SEQUENCE  BoardId_seq;

-- insert 구문 (삽입) C
INSERT INTO Gallery_Board VALUES( BoardId_seq.NEXTVAL,'real','미니','아 넘 어려워',sysdate,'2',1);



--파일형

CREATE SEQUENCE file_board_seq;
INSERT INTO file_board(b_no, title, content, writer, reg_date) VALUES(file_board_seq.NEXTVAL, '피카피카!.', '쮸..? 피카피카!?', 'pikachu');

CREATE SEQUENCE files_seq;
