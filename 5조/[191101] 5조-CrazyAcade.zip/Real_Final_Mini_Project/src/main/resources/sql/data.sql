INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '할로윈 눈알 호박 잘나오는모드 어디예요?', '호얍', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, '만두 옮기기인거 같아요...', '아량', '그래선지 만두 옮기기 매칭되면<br>중국인들도 한국인들도 다 파밍만하고 있더라구요...', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 2, '오 그렇쿤요!', '호얍', '오 그렇쿤요!', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, '호박은 노멀 래더 눈알은 만옮이여!', '하얘찡', '만옮하다보믄 모으시는분들 좀 계셔서 수월하실수도?ㅎㅎ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 4, '전혀 수월안한거같은데요', '호얍', '스틸함', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 5, '엥...에반데..', '하얘찡', '간혹 그런분들 계시긴해여😣<br>폭격으루 내 쪽 블럭 많은곳에 깨면 잘 나오던데용ㅠ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, '눈알은 만두 호박은 클래식이나 노멀 래더욘><', '성패', '><', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 7, '눈알은 포기해야될듯요', '호얍', '오늘이야 모으는건데', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 1, '보물섬이요', '튀궁', '보물섬이요', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 9, '헐 보물섬 생각못했네요!', '호얍', '!!!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 10, '한 4~5개씩 나와요', '튀궁', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 1, 9, '보물섬에서 이벤트 아이템이 드랍된다구요?', '매일경제', '.', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, null, '버패기간 얼마안남으면 2배보너스이벤트 했는데', '가라쿠타', '이번시즌은 안하나요...?<br>ㅜㅜ', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 13, 13, '토일월 12~20시 두배니까', '대프리카', '이때 서바해보셔용', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 13, 13, '이번시즌도 있어용!!', '성패', '이번시즌도 있어용!!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, null, '승리 상자가 뭐에요?	', '개늑시', '승리 상자가 뭐에요?', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 16, 16, '10번 승리하면 열 수 있는 상자에요.', '세리ㅇ', '10번 승리하면 열 수 있는 상자에요.<br>오른쪽 맨 끝 보라색상자에요', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 16, 17, '아~ 감사합니다ㅎㅎ', '개늑시', 'ㅎㅎ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 16, 16, '개와 늑대의 시간?!', '하얘찡', '닉넴??', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 16, 19, '네 맞아요ㅋㅋ', '개늑시', 'ㅎㅎ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 16, 20, '헤헿 올만에 듣는당ㅎㅎ', '하얘찡', 'ㅎㅎ', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '사탕호박,,어디로사라짐?ㅠ', '랄랄라랄', '왜안보이는걸까아아..<br>눈알은다먹엇는데 호박사탕이엄땅<br><br>어디서구해야하는건가......!', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 22, 22, '호박은', '성패', '호박은 노멀 클래식에서 많이 봤궁 사탕은 서바에서 자주 나오드라구연!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 22, 23, '호박.. 노멀에서먹기 넘힘듬', '랄랄라랄', 'ㅠ바로시작해서ㅠㅠㅠ헝', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 22, 22, '헐 만두 많이 하시나봐요..', '산쪼갓', '남들은 눈알없어서 난린데 부럽 ㅠ<br>노멀 서바 둘 다 만두보다 블록많아서 금방드실거에여<br>화이팅', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 22, 25, '4일눈알빠지게 만두만했슴댱..ㅠㅠ', '랄랄라랄', '4일눈알빠지게 만두만했슴댱..ㅠㅠ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 22, 22, '사탕 : 서바 노멀 : 호박', '꼴통보스', '사탕 : 서바 노멀 : 호박', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '머리가 아프면 약을 몇통먹는지아심?', '하기스골드매직팬티', '<br><br><br><br><br>답은 "두통" 입니다<br><br>껄껄껄', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 28, 28, 'ㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋㅋ ㅡㅡ', '모하메드살라', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 28, 28, '껄껄껄', '꼬물꼬물', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 28, 28, '두 통 통째로 부어드릴까요...', 'drens', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 28, 28, '교수님,약을 과다섭취하였을때', '아량', '간이 약물을 분해 못 시켜서 약물 중독으로 죽는게 맞죠?', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 28, 28, '앜ㅋㅋㅋㅋ 내스탈이양><', '성패', 'bb', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '2:00 2:30 시작 ㅇㅋ? 이러는이유가 뭐일까요', '가라쿠타', '만옮에서 몇몇이 바로시작안하고 이러던데', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 34, '눈알먹으려구 그래여', '성패', '눈알먹으려구 그래여', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 35, '그때시작하면 눈알나와여?', '가라쿠타', '??', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 34, '눈알 파밍이요!', '아량', '그때 블럭 부수면 나올 확률이 더 높아져요!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 37, '헤에 첨 알았네요', '가라쿠타', '근데 만두만 그런가요?', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 38, '다들 만두 먹기보단 만두 옮기기에서 파밍할거에요', '아량', '차이가 뭔진 모르겠는데...', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 34, 39, '음 블럭수 차이?', '가라쿠타', '음 블럭수 차이?', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '다들 목처 몇이신가여', '배찌이', '원폭으로 다시 갈아타고 3킬이상내는데<br>1.6에서 움직이질 않네유...<br>몇달째 1.6인듯..<br>왜구러지..<br><br><br>+)알았네여<br>목숨당이라 안오르는거였네여.. <br>제가 바늘은 안끼고 다녀서 많이죽고 많이 처치해서 안오르는 거였네여... ㅜㅠㅠㅠㅜ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '기준은', '초아', '노멀2이상고수<br>1:1 2이상초고수<br>서바이벌 3이상고수<br>래더 1.0이상 평균이상 1.5이상 초고수', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 42, '노멀 1.6... 래더 1.4...', '배찌이', '평균이네유ㅜㅜ 왜 안오르지ㅜㅜ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 43, '판수는', '초아', '노멀1000판이상,1:1 100판이상 서바이벌 100판이상 래더 1000판이상 기준입니당', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 42, '노멀 2.2, 래더 1.6, 서바이벌 4.1, 1:1 3', '무궁화를 향하여', '초보지만 왠지 기분은 좋다', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 45, '1:1 3이면 ㄷㄷ', '배찌이', '몇판하셨길래 3이 나오져 ㅎㄷㄷ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 42, '와 래더만 고수라니 말도안돼~~', '성패', '초본뎅', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '노멀 625전 5.3 래더는 패작 하느라 1.1', '치끙', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 48, '5.3이요...?', '배찌이', '2.3아니구여..?', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 49, '5.3 입니다', '치끙', '5.3 입니다', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 50, '5.3이 나올수 있어요???', '배찌이', '1판에 5번처치하는데 어떻게 5이상 나와여???', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 51, '한판이 아니고', '치끙', '안죽고 5번이상 처치입니다', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 52, '아 한판이 아니라 목숨당이구나', '배찌이', '안죽고 연속으로 5킬이상 한다는소리인데 ㅎㄷㄷ<br>어떻게 그러져 대단쓰..', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '구경만 해야징~~', '개복치', '총총', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 54, '총총2', '하얘찡', '총총2', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '노말 1.3 래더 1.1 ㅠㅠ', '페코라', 'ㅜㅜ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '래더는 1.3 노말은 1.5...', '아량', '서바이벌들은 둘 다 3이상이네요...<br><br>저는 그냥 초보 수준인듯', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 41, 41, '목처 중요하지 않아요~', '쓰레기잡는 저격수', '승률 목처 다 필요 없어요<br>실력이랑 사실상 무관하잖아요<br>어느 정도 포함은 있지만!<br>화이팅이요!!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '펫 축복 확률 낮아지나요?', '크아초보님', '펫 지금 24퍼인데 펫축복하기?<br>그거하면.확률이 떨어지기도하나요?<br>업그레이드할까.축복할까 고민중', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 59, 59, '아뇨', '대프리카', '기존값으로 선택할수도 있어서 떨어지진 않습니다!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 59, 60, '마자용', '성패', '마자용', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, stair_shaped_board_seq.CURRVAL, NULL, '님들 궁금한게 있는데', '페코라', '만약 래더1등 듀오로 공동점수면 어케됨?<br><br>1등날개 두명이받음?<br><br>그런사례 혹시 있었나요??', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 62, '궁금하당', '성패', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 63, '저랑은 거리가 먼 얘기지만 궁금 ㅎ', '페코라', 'ㅎㅎ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 62, '동일점수면', '고말숙', '동일점수면 누가 더 빨리 점수를 올렸는지,<br>즉 동일 점수 상황이 되기 전에 먼저 점수를 올린 사람이 랭킹이 높습니다.<br.>만약 시즌 처음부터 계속 함께 점수를 올렸다 해도 랭킹이 겹치는 일은 없구요.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 65, '시즌 처음부터 같이하면 점수가 같을텐데', '페코라', '랭킹이 겹치지 않을까요..?<br><br>흠... 왜 안 겹치지', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 66, '래더 순위에 겹치는 일은 아예 없습니다.', '고말숙', '.', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 67, '그러네여 같은 점수여도 무조건 갈리는군여...', '페코라', '답변 감사합니다 말숙님!<br><br>폭격 일인자 말숙님 폭격 잘쓰려면 화면 큰 폰이 좋을까여?!', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 68, '저는 아이폰 XR 사용하고 있는데', '고말숙', '너무 크지는 않고 5인치 정도가 적당할 거 같아여', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 62, '시즌 처음부터 끝까지 같이하면', '변화', '가나다abc 순서로 나뉘지 않을까요 흠', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 70, '고작 닉네임때문에 누군 1등타고 2등타면', '페코라', '진짜 억울하겠다...ㅋㅋㅋ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 62, '페코라님 인겜 답 왜안하주세오 ㅡ3ㅡ', '줄즈', 'ㅡ3ㅡ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 72, '크흠 방금 봤어요 ㅋㅋㅋ', '페코라', '부계 맞는데 비밀임 쉿..!<br>발설하면 안대요<br>거의 무정수라 피해드릴까봐 조마조마했는데 이겨주셔서 넘멋졌오요 ㅎㅎㅎ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 73, 'ㅎㅎㅎ페코라님 냄새났어요 !', '줄즈', '이럴거였으면 본캐에 꽃드릴걸 힝 ㅠ', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 62, '듀오여도 킬수뭐 그런거에따라 점수를 다르게 받지않아요?', '츈리', '...점수똑같앗는데 저번에 이기고 후에 올라간점수가 다르던데 ..', 0
);

INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 75, '정말여??? ', '페코라', '똑같은 상태에서 달라지는건 첨듣네여 ㄷㄷ', 0
);
INSERT INTO stair_shaped_board(no, grpno, prntno, title, writer, content, hits) VALUES(
stair_shaped_board_seq.NEXTVAL, 62, 76, '제가잘못본걸수도....ㅠ ', '츈리', 'ㅠ', 0
);


INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'내일이면11월달이구나','테르슈테켄'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'문화가 있는 날 + 스타벅스','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'조알망','남순OI'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'발전','들향tr'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'일기쓰기의 전통을 물려주다','rkdals13118'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'루찌','rkddkwl4459'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'우리길드 화이팅','시크한유전자'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'빅뱅 지드래곤 전역','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'에라 모르겠다','황금뽀끼'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'에효 난 일본 가고 싶네','황금뽀끼'
,'매국노',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'ㅇㅎ','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'문화가 있는 날 + 스타벅스','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'문화가 있는 날 + 스타벅스','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'빅뱅 지드래곤 전역','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'에라 모르겠다','황금뽀끼'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'에효 난 일본 가고 싶네','황금뽀끼'
,'매국노',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'ㅇㅎ','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'문화가 있는 날 + 스타벅스','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'문화가 있는 날 + 스타벅스','rkdals1318'
,'5조짱짱',default,default);

INSERT INTO
      List_Board (idx,title,writer,content,reg_date,view_cnt) VALUES
      (List_Board_seq.nextval,'내일이면11월달이구나','테르슈테켄'
,'5조짱짱',default,default);

CREATE SEQUENCE BoardId_seq;
CREATE SEQUENCE file_board_seq;

CREATE SEQUENCE fno_seq;
